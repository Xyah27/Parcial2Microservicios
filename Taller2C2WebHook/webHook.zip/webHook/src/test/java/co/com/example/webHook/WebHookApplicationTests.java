package co.com.example.webHook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebHookApplicationTests {

	@Test
	void contextLoads() {
	}

}
